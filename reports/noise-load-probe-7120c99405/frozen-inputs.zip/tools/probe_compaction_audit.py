"""Replay real native receipts through the new per-summary audit join."""
import json,sys,uuid
from types import SimpleNamespace
from datetime import datetime,timezone
from asuna.config import ROOT,BUNDLE,load
from asuna.evidence import Evidence,write_json,sha
from asuna.experiments import freeze
from asuna.dsh_lane import compaction_audit_records
from asuna.audit import render_html

ev=Evidence(ROOT/'reports'/('compaction-audit-probe-'+uuid.uuid4().hex[:10]))
manifest=freeze(load(),BUNDLE/'fixtures/acceptance_cases.json',ev,'PROBE-COMPACTION-AUDIT')
source=ROOT/'reports/noise-load-probe-828cf4480a/noise-0001';calls=[];sources=[]
def ref(path):return {'artifact_path':path.relative_to(ROOT).as_posix(),'sha256':sha(path.read_bytes())}
for path in sorted(source.glob('*provider.response.json')):
    response=json.loads(path.read_text(encoding='utf-8'))['payload']
    if 'body_utf8' not in response:continue
    request_path=source/response['request_ref'];request=json.loads(request_path.read_text(encoding='utf-8'))['payload']
    calls.append({'call_id':response['call_id'],'request_ref':request_path.name,'response_ref':path.name,
                  'body':json.loads(request['body_utf8']),'raw':response['body_utf8']})
    sources.extend([ref(request_path),ref(path)])
records=[]
for path in source.glob('*lane.receipt.json'):
    body=json.loads(path.read_text(encoding='utf-8'))['payload']['body']
    if not body.get('compactions'):continue
    sources.append(ref(path))
    records+=compaction_audit_records(body,calls,SimpleNamespace(root=source))
assert len(records)==2 and all(r['provider_summary_join']=='EXACT_CONTENT_AND_OPERATION' for r in records)
assert len({r['result']['compactionId'] for r in records})==2
assert all({e['data']['compactionId'] for e in r['events']}=={r['result']['compactionId']} for r in records)
write_json(ev.root/'reconstructed-records.json',{'source':sources,'records':records,'mode':'reconstruction from preserved actual native receipts; not newly generated summaries'})
rollback=ROOT/'reports/rollback-probe-37f922b40d/trace.json'
render_html(json.loads(rollback.read_text(encoding='utf-8')),ev.root/'revision-trace.html')
assert 'parent ' in (ev.root/'revision-trace.html').read_text(encoding='utf-8'))
write_json(ev.root/'result.json',{'test_id':'PROBE-COMPACTION-AUDIT','status':'PASS','mode':'recorded_real_native_boundary_replay',
 'experiment_id':manifest['experiment_id'],'executed_at':datetime.now(timezone.utc).isoformat(),
 'manifest_sha256':sha((ev.root/'manifest.json').read_bytes()),'commands':[{'argv':[sys.executable,*sys.argv],'exit_code':0}],
 'assertions':[{'name':'Each of two native summaries has exact provider content match and individual bracket','passed':True}],
 'limitations':['New live route verification is separate. Old Mongo traces stored only the last compaction per operation; all native results remain in the raw lane receipt.']})
print(json.dumps({'run':ev.root.name,'status':'PASS','native_summaries':len(records)}))
